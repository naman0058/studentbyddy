/* script.js */
document.querySelector('.profile-pic').addEventListener('click', function() {
    // Redirect to user's profile page
    // Replace 'profile.html' with actual profile page URL
    window.location.href = '/template/profile.html';
});

// Code for generating content for the buddies section
const buddiesContainer = document.querySelector('.buddies-container');

const buddiesData = [
    { name: 'Devanshi Chauhan', university: 'MPSTME', image: '/static/devanshi.png', eating: 'Non - Veg', age: '21', status: 'Student', location: 'Kandivali', sleepingHabits: 'Early riser', hobbies: 'Reading, hiking' },
    { name: 'Khushi Patel', university: 'MPSTME', image: '/static/khushi.png', eating: 'Veg', age: '21', status: 'Student', location: 'Kandivali', sleepingHabits: 'Night owl', hobbies: 'Playing guitar, painting' },
    { name: 'Divya Bhendawadekar', university: 'MPSTME', image: '/static/divya.png', eating: 'Non - Veg', age: '21', status: 'Student', location: 'Kandivali', sleepingHabits: 'Light sleeper', hobbies: 'Cooking, gardening' },
    { name: 'Olashee Ranasingh', university: 'MPSTME', image: '/static/olashee.png', eating: 'Non - Veg', age: '21', status: 'Student', location: 'Kandivali', sleepingHabits: 'Late sleeper', hobbies: 'Photography, traveling' },
    { name: 'Prashil Vachhani', university: 'MPSTME', image: '/static/prashil.jpeg', eating: 'Veg', age: '21', status: 'Student', location: 'Kandivali', sleepingHabits: 'Early riser', hobbies: 'Playing sports, watching movies' },
    { name: 'Dhrumil Burad', university: 'MPSTME', image: '/static/dhrumil.jpg', eating: 'Veg', age: '21', status: 'Student', location: 'Kandivali', sleepingHabits: 'Night owl', hobbies: 'Gaming, cooking' },
    { name: 'Saachi Kaup', university: 'MPSTME', image: '/static/saachi.jpg', eating: 'Non - Veg', age: '21', status: 'Student', location: 'Kandivali', sleepingHabits: 'Late sleeper', hobbies: 'Programming, reading novels' },
    { name: 'Shreya Govil', university: 'MPSTME', image: '/static/Shreya.jpg', eating: 'Veg', age: '21', status: 'Student', location: 'Kandivali', sleepingHabits: 'Early riser', hobbies: 'Traveling, playing musical instruments' },
    { name: 'Mahima Arora', university: 'MPSTME', image: '/static/mahima.jpg', eating: 'Non - Veg', age: '21', status: 'Student', location: 'Kandivali', sleepingHabits: 'Light sleeper', hobbies: 'Dancing, watching documentaries' }
];

buddiesData.forEach(buddy => {
    const buddyDiv = document.createElement('div');
    buddyDiv.classList.add('buddy');

    const image = document.createElement('img');
    image.src = buddy.image;
    image.alt = buddy.name;

    const nameHeading = document.createElement('h3');
    nameHeading.textContent = buddy.name;

    const universityText = document.createElement('h5');
    universityText.textContent = buddy.university;

    const eatingParagraph = document.createElement('p');
    eatingParagraph.textContent = buddy.eating;

    // Add click event listener to dynamically redirect to profile page with URL parameters
    buddyDiv.addEventListener('click', () => {
        const profilePageURL = `roommateprofile.html?name=${encodeURIComponent(buddy.name)}&university=${encodeURIComponent(buddy.university)}&eating=${encodeURIComponent(buddy.eating)}&image=${encodeURIComponent(buddy.image)}&age=${encodeURIComponent(buddy.age)}&status=${encodeURIComponent(buddy.status)}&location=${encodeURIComponent(buddy.location)}&sleepingHabits=${encodeURIComponent(buddy.sleepingHabits)}&hobbies=${encodeURIComponent(buddy.hobbies)}`;
        window.location.href = profilePageURL;
    });

    buddyDiv.appendChild(image);
    buddyDiv.appendChild(nameHeading);
    buddyDiv.appendChild(universityText);
    buddyDiv.appendChild(eatingParagraph); // Corrected this line

    // Only on the sbprofile.html page, append age, status, and location to the buddyDiv
    if (window.location.pathname.includes('roommateprofile.html')) {
        const ageParagraph = document.createElement('p');
        ageParagraph.textContent = `Age: ${buddy.age}`;

        const statusParagraph = document.createElement('p');
        statusParagraph.textContent = `Status: ${buddy.status}`;

        const locationParagraph = document.createElement('p');
        locationParagraph.textContent = `Location: ${buddy.location}`;

        const sleepingHabitsParagraph = document.createElement('p');
        sleepingHabitsParagraph.textContent = `Sleeping Habits: ${buddy.sleepingHabits}`;

        const hobbiesParagraph = document.createElement('p'); // Create hobbies paragraph
        hobbiesParagraph.textContent = `Hobbies: ${buddy.hobbies}`; // Set hobbies content

        buddyDiv.appendChild(ageParagraph);
        buddyDiv.appendChild(statusParagraph);
        buddyDiv.appendChild(locationParagraph);
        buddyDiv.appendChild(sleepingHabitsParagraph);
        buddyDiv.appendChild(hobbiesParagraph); // Append hobbies paragraph
    }

    buddiesContainer.appendChild(buddyDiv);
});
